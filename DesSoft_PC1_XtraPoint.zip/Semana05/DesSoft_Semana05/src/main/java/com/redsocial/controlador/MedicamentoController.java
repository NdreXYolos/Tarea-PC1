package com.redsocial.controlador;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.redsocial.entidad.Medicamento;
import com.redsocial.servicio.MedicamentoServicio;

@Controller
public class MedicamentoController {
	
	@Autowired
	private MedicamentoServicio servicio;
	
    @RequestMapping("/verMedicamento")
	public String verPagina(Model m) {
		List<Medicamento> list = servicio.listaMedicamento("");
		m.addAttribute("medicamentos", list);
		return "crudMedicamento";
	}
    
    @RequestMapping("/listaMedicamento")
	public String lista(@RequestParam Map<String,String> params, Model m) {
		List<Medicamento> list = servicio.listaMedicamento(params.get("filtro"));
		m.addAttribute("medicamentos", list);
		return "crudMedicamento";
	}
    
    @RequestMapping("/registraMedicamento")
	public String metodoRegistra(Medicamento obj, Model m) {
		servicio.insertaMedicamento(obj);
		List<Medicamento> list = servicio.listaMedicamento("");
		m.addAttribute("medicamentos", list);
		return "crudMedicamento";
	}
    
    @RequestMapping("/actualizaMedicamento")
	public String metodoActualiza(Medicamento obj, Model m) {
		servicio.actualizaMedicamento(obj);
		List<Medicamento> list = servicio.listaMedicamento("");
		m.addAttribute("concursos", list);
		return "crudConcurso";
	}
    
    
    
}
