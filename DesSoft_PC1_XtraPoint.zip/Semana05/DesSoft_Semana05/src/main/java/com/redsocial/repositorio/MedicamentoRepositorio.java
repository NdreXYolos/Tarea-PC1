package com.redsocial.repositorio;

import java.util.List;

import com.redsocial.entidad.Medicamento;

public interface MedicamentoRepositorio {
	public abstract int elimina(int idMedicamento) ;
	public abstract int inserta(Medicamento  obj) ;
	public abstract int actualiza(Medicamento obj) ;
	public abstract List<Medicamento> lista(String filtro) ;
}
