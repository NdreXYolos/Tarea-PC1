package com.redsocial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesSoftSemana04Application {

	public static void main(String[] args) {
		SpringApplication.run(DesSoftSemana04Application.class, args);
	}

}
